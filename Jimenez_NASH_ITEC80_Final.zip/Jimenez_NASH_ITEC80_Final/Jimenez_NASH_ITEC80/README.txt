NASH PRINTING SHOP MANAGEMENT SYSTEM
ITEC 80 - High-Fidelity Prototype
Prepared by: Steven P. Jimenez

PROJECT CONTENTS
- index.html: page structure and six main views
- style.css: responsive user interface styles
- script.js: navigation, forms, records, quotation approval, job status, payment recording, search, and CSV export

HOW TO RUN
1. Extract the ZIP file.
2. Open the Jimenez_NASH_ITEC80 folder in Visual Studio Code.
3. Open index.html with Live Server, or double-click index.html to open it in a browser.
4. Use the left-side navigation to explore the six views.

DEMO WORKFLOW
1. Open New Request and fill in the customer, service, quantity, target date, and description.
2. Click Save request and continue. A customer record and pending quotation are saved.
3. Open Quotations, click Approve, and enter a quotation amount in Philippine pesos.
4. The system creates a Job Order. Open Job Orders and update its production status.
5. Once the job is ready or completed, click Record payment and enter the amount and payment method.
6. Open Payments & Records to see the saved transaction. Use Export CSV to download the payment table.

FEATURES
- Dashboard cards and recent job orders
- Customer request form with required-field and date validation
- Customer records and search
- Quotation approval/rejection and job-order creation
- Production status updates
- Payment transaction records and CSV export
- Responsive layout for desktop and mobile
- Local browser storage to keep demo records between refreshes

USABILITY ISSUES IDENTIFIED AND DESIGN IMPROVEMENTS
1. Issue: Paper records can be difficult to locate.
   Improvement: Customer, quotation, job-order, and payment records are grouped into separate views with search fields where useful.
2. Issue: The owner may lose track of production status.
   Improvement: Job Orders has a visible status label and a control to update the current production stage.
3. Issue: Payments may be hard to match with the correct order.
   Improvement: Payment recording is launched from the related job order and creates a transaction ID with job ID, customer, amount, method, and date.

LIMITATIONS
- This is a classroom prototype only. It is not connected to a real database, authentication service, printer, or payment gateway.
- Records are saved in localStorage on the current browser and computer. Clearing browser data removes the demo records.
- Quotation amount and payment details are entered for demonstration; do not use real customer or financial information.
- The system has not been deployed to a public website. If your instructor specifically requires a public URL, publish this folder with GitHub Pages, Netlify, or Vercel and submit the deployed link.

SCREENSHOTS TO CAPTURE BEFORE SUBMISSION
Capture the following views after running the project:
1. Dashboard
2. New Customer Request
3. Customers
4. Quotations (after creating a sample request)
5. Job Orders (after approving a quotation)
6. Payments & Records (after recording a demo payment)
Also capture the request-saved and payment-recorded confirmation dialogs if your instructor asks for workflow evidence.

SAMPLE TEST
Use fictional demo data only:
Customer: ABC Sample Trading
Phone: 09123456789
Service: Business Cards
Quantity: 100
Target date: choose a future date
Description: Sample business card printing, front and back
When approving the quotation, enter a sample amount such as 1500. Then update the job status and record a sample payment.

Prepared as a student prototype for demonstration. All records and prices are fictional.
