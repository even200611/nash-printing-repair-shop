const STORE_KEY = "nashPrintingPrototype_v1";
const initialData = { customers: [], requests: [], quotations: [], jobs: [], payments: [] };
let data = loadData();
let toastTimer;

function loadData() {
  try {
    const saved = localStorage.getItem(STORE_KEY);
    return saved ? { ...initialData, ...JSON.parse(saved) } : structuredClone(initialData);
  } catch (error) {
    return structuredClone(initialData);
  }
}
function saveData() { localStorage.setItem(STORE_KEY, JSON.stringify(data)); renderAll(); }
function makeId(prefix, list) {
  const next = list.length + 1;
  return `${prefix}-${String(next).padStart(4, "0")}`;
}
function money(value) {
  return new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" }).format(Number(value) || 0);
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[char]));
}
function formatDate(value) {
  if (!value) return "—";
  const date = new Date(`${value}T00:00:00`);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" });
}
function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}
function showModal(title, message, details = "") {
  document.getElementById("modalTitle").textContent = title;
  document.getElementById("modalMessage").textContent = message;
  document.getElementById("modalDetails").textContent = details;
  document.getElementById("modalBackdrop").classList.add("open");
}
function closeModal() { document.getElementById("modalBackdrop").classList.remove("open"); }
function statusClass(status) {
  return String(status).toLowerCase().replace(/\s+/g, "-");
}
function badge(status) {
  return `<span class="status ${statusClass(status)}">${escapeHtml(status)}</span>`;
}
function navigate(page) {
  document.querySelectorAll(".page").forEach(section => section.classList.toggle("active", section.id === `page-${page}`));
  document.querySelectorAll(".nav-link").forEach(button => button.classList.toggle("active", button.dataset.page === page));
  const active = document.querySelector(`.nav-link[data-page="${page}"]`);
  document.getElementById("pageCrumb").textContent = active ? active.textContent.trim() : "Dashboard";
  document.getElementById("sidebar").classList.remove("open");
  window.scrollTo({ top: 0, behavior: "smooth" });
}
function getCustomer(name, phone, email) {
  let customer = data.customers.find(item => item.name.toLowerCase() === name.toLowerCase() && item.phone === phone);
  if (!customer) {
    customer = { id: makeId("CUS", data.customers), name, phone, email, createdAt: new Date().toISOString() };
    data.customers.push(customer);
  } else if (email && !customer.email) customer.email = email;
  return customer;
}
function renderDashboard() {
  document.getElementById("statCustomers").textContent = data.customers.length;
  document.getElementById("statQuotes").textContent = data.quotations.filter(q => q.status === "Pending").length;
  document.getElementById("statJobs").textContent = data.jobs.filter(j => j.status !== "Completed").length;
  document.getElementById("statPayments").textContent = money(data.payments.reduce((sum, p) => sum + Number(p.amount), 0));
  const body = document.getElementById("dashboardJobs");
  const jobs = [...data.jobs].reverse().slice(0, 5);
  body.innerHTML = jobs.map(job => `<tr><td>${escapeHtml(job.id)}</td><td>${escapeHtml(job.customerName)}</td><td>${escapeHtml(job.service)}</td><td>${formatDate(job.dueDate)}</td><td>${badge(job.status)}</td></tr>`).join("");
  document.getElementById("dashboardJobsEmpty").classList.toggle("show", jobs.length === 0);
}
function renderCustomers() {
  const query = (document.getElementById("customerSearch").value || "").toLowerCase();
  const customers = data.customers.filter(c => `${c.name} ${c.phone} ${c.email}`.toLowerCase().includes(query));
  document.getElementById("customerCount").textContent = `${customers.length} record${customers.length === 1 ? "" : "s"}`;
  document.getElementById("customersTable").innerHTML = customers.map(c => {
    const orders = data.requests.filter(r => r.customerId === c.id).length;
    return `<tr><td>${escapeHtml(c.id)}</td><td>${escapeHtml(c.name)}</td><td>${escapeHtml(c.phone)}</td><td>${escapeHtml(c.email || "—")}</td><td>${orders}</td></tr>`;
  }).join("");
  document.getElementById("customersEmpty").classList.toggle("show", customers.length === 0);
}
function renderQuotes() {
  const query = (document.getElementById("quoteSearch").value || "").toLowerCase();
  const quotes = [...data.quotations].reverse().filter(q => `${q.id} ${q.customerName} ${q.service} ${q.status}`.toLowerCase().includes(query));
  document.getElementById("quoteCount").textContent = `${quotes.length} record${quotes.length === 1 ? "" : "s"}`;
  document.getElementById("quotesTable").innerHTML = quotes.map(q => {
    let action = q.status === "Pending"
      ? `<button class="table-action primary-action" data-quote-action="approve" data-id="${q.id}">Approve</button> <button class="table-action" data-quote-action="reject" data-id="${q.id}">Reject</button>`
      : badge(q.status);
    return `<tr><td>${escapeHtml(q.id)}</td><td>${escapeHtml(q.customerName)}</td><td>${escapeHtml(q.service)}</td><td>${q.quantity}</td><td>${money(q.total)}</td><td>${action}</td></tr>`;
  }).join("");
  document.getElementById("quotesEmpty").classList.toggle("show", quotes.length === 0);
}
function renderJobs() {
  const query = (document.getElementById("jobSearch").value || "").toLowerCase();
  const jobs = [...data.jobs].reverse().filter(j => `${j.id} ${j.customerName} ${j.service} ${j.status}`.toLowerCase().includes(query));
  document.getElementById("jobCount").textContent = `${jobs.length} record${jobs.length === 1 ? "" : "s"}`;
  document.getElementById("jobsTable").innerHTML = jobs.map(j => {
    let actions = j.status === "Completed" ? `<button class="table-action" data-job-action="payment" data-id="${j.id}">Record payment</button>` :
      `<select class="table-action" aria-label="Update status for ${j.id}" data-job-status="${j.id}">
      ${["Queued","In Production","Ready for Pickup","Completed"].map(s => `<option ${s === j.status ? "selected" : ""}>${s}</option>`).join("")}</select>`;
    if (j.status === "Ready for Pickup") actions = `<select class="table-action" aria-label="Update status for ${j.id}" data-job-status="${j.id}">${["Queued","In Production","Ready for Pickup","Completed"].map(s => `<option ${s === j.status ? "selected" : ""}>${s}</option>`).join("")}</select> <button class="table-action primary-action" data-job-action="payment" data-id="${j.id}">Record payment</button>`;
    return `<tr><td>${escapeHtml(j.id)}</td><td>${escapeHtml(j.customerName)}</td><td>${escapeHtml(j.service)}</td><td>${formatDate(j.dueDate)}</td><td>${badge(j.status)}</td><td class="no-wrap">${actions}</td></tr>`;
  }).join("");
  document.getElementById("jobsEmpty").classList.toggle("show", jobs.length === 0);
}
function renderPayments() {
  const total = data.payments.reduce((sum, p) => sum + Number(p.amount), 0);
  document.getElementById("paymentTotal").textContent = money(total);
  document.getElementById("paymentCount").textContent = data.payments.length;
  document.getElementById("paymentsTable").innerHTML = [...data.payments].reverse().map(p =>
    `<tr><td>${escapeHtml(p.id)}</td><td>${escapeHtml(p.jobId)}</td><td>${escapeHtml(p.customerName)}</td><td>${money(p.amount)}</td><td>${escapeHtml(p.method)}</td><td>${formatDate(p.date)}</td></tr>`
  ).join("");
  document.getElementById("paymentsEmpty").classList.toggle("show", data.payments.length === 0);
}
function renderAll() { renderDashboard(); renderCustomers(); renderQuotes(); renderJobs(); renderPayments(); }

document.querySelectorAll(".nav-link").forEach(button => button.addEventListener("click", () => navigate(button.dataset.page)));
document.querySelectorAll("[data-go]").forEach(button => button.addEventListener("click", () => navigate(button.dataset.go)));
document.getElementById("menuButton").addEventListener("click", () => document.getElementById("sidebar").classList.toggle("open"));
document.getElementById("modalClose").addEventListener("click", closeModal);
document.getElementById("modalBackdrop").addEventListener("click", event => { if (event.target.id === "modalBackdrop") closeModal(); });
document.addEventListener("keydown", event => { if (event.key === "Escape") closeModal(); });
["customerSearch", "quoteSearch", "jobSearch"].forEach(id => document.getElementById(id).addEventListener("input", renderAll));

document.getElementById("requestForm").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const customerName = String(form.get("customer")).trim();
  const phone = String(form.get("phone")).trim();
  const email = String(form.get("email")).trim();
  const service = String(form.get("service"));
  const quantity = Number(form.get("quantity"));
  const dueDate = String(form.get("dueDate"));
  const description = String(form.get("description")).trim();
  if (!customerName || !phone || !service || !quantity || quantity < 1 || !dueDate || !description) {
    showToast("Please complete all required fields.");
    return;
  }
  if (dueDate < new Date().toISOString().slice(0, 10)) {
    showToast("Target completion date cannot be in the past.");
    return;
  }
  const customer = getCustomer(customerName, phone, email);
  const request = { id: makeId("REQ", data.requests), customerId: customer.id, customerName, phone, email, service, quantity, dueDate, description, createdAt: new Date().toISOString() };
  data.requests.push(request);
  const quote = { id: makeId("QUO", data.quotations), requestId: request.id, customerId: customer.id, customerName, service, quantity, total: 0, status: "Pending", createdAt: new Date().toISOString() };
  data.quotations.push(quote);
  saveData();
  event.currentTarget.reset();
  showModal("Request saved successfully", "A customer record and pending quotation have been created.", `Request ID: ${request.id}\nCustomer: ${customerName}\nService: ${service}\nQuotation ID: ${quote.id}\nNext step: open Quotations and enter an estimate by approving the quote.`);
  navigate("quotations");
});
document.getElementById("quotesTable").addEventListener("click", event => {
  const button = event.target.closest("[data-quote-action]");
  if (!button) return;
  const quote = data.quotations.find(q => q.id === button.dataset.id);
  if (!quote) return;
  if (button.dataset.quoteAction === "reject") {
    quote.status = "Rejected";
    saveData();
    showToast(`${quote.id} marked as rejected.`);
    return;
  }
  const request = data.requests.find(r => r.id === quote.requestId);
  const suggested = Math.max(0, Number(quote.total) || 0);
  const raw = prompt(`Enter total quotation amount in PHP for ${quote.customerName} (${quote.service}, quantity ${quote.quantity}):`, suggested ? String(suggested) : "");
  if (raw === null) return;
  const amount = Number(raw);
  if (!Number.isFinite(amount) || amount <= 0) { showToast("Enter an amount greater than ₱0."); return; }
  quote.total = amount;
  quote.status = "Approved";
  const job = { id: makeId("JOB", data.jobs), quotationId: quote.id, requestId: quote.requestId, customerId: quote.customerId, customerName: quote.customerName, service: quote.service, quantity: quote.quantity, dueDate: request ? request.dueDate : "", description: request ? request.description : "", total: amount, status: "Queued", createdAt: new Date().toISOString() };
  data.jobs.push(job);
  saveData();
  showModal("Quotation approved", "The customer quotation was approved and a job order was created.", `Quotation: ${quote.id}\nJob Order: ${job.id}\nCustomer: ${job.customerName}\nEstimated total: ${money(amount)}\nNext step: update the production status in Job Orders.`);
  navigate("jobs");
});
document.getElementById("jobsTable").addEventListener("change", event => {
  const jobId = event.target.dataset.jobStatus;
  if (!jobId) return;
  const job = data.jobs.find(j => j.id === jobId);
  if (!job) return;
  job.status = event.target.value;
  saveData();
  showToast(`${job.id} status updated to ${job.status}.`);
});
document.getElementById("jobsTable").addEventListener("click", event => {
  const button = event.target.closest("[data-job-action='payment']");
  if (!button) return;
  const job = data.jobs.find(j => j.id === button.dataset.id);
  if (!job) return;
  const raw = prompt(`Enter payment amount in PHP for ${job.id}. Outstanding balance: ${money(job.total - data.payments.filter(p => p.jobId === job.id).reduce((sum, p) => sum + Number(p.amount), 0))}`, String(job.total));
  if (raw === null) return;
  const amount = Number(raw);
  if (!Number.isFinite(amount) || amount <= 0) { showToast("Enter an amount greater than ₱0."); return; }
  const method = prompt("Payment method (Cash, GCash, Bank Transfer, Other):", "Cash");
  if (method === null || !method.trim()) return;
  const payment = { id: makeId("PAY", data.payments), jobId: job.id, customerName: job.customerName, amount, method: method.trim(), date: new Date().toISOString().slice(0, 10) };
  data.payments.push(payment);
  const paid = data.payments.filter(p => p.jobId === job.id).reduce((sum, p) => sum + Number(p.amount), 0);
  if (paid >= job.total) job.paymentStatus = "Paid";
  else job.paymentStatus = "Partial";
  saveData();
  showModal("Payment recorded", "The payment transaction has been saved in the demo records.", `Transaction: ${payment.id}\nJob Order: ${job.id}\nAmount: ${money(amount)}\nMethod: ${payment.method}\nPayment status: ${job.paymentStatus}`);
  navigate("payments");
});
document.getElementById("exportBtn").addEventListener("click", () => {
  if (!data.payments.length) { showToast("There are no payment records to export yet."); return; }
  const rows = [["Transaction ID","Job Order","Customer","Amount","Payment Method","Date"], ...data.payments.map(p => [p.id,p.jobId,p.customerName,p.amount,p.method,p.date])];
  const csv = rows.map(row => row.map(value => `"${String(value).replace(/"/g, '""')}"`).join(",")).join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url; link.download = "nash-payment-records.csv"; link.click();
  URL.revokeObjectURL(url);
  showToast("Payment records exported.");
});

document.getElementById("todayLabel").textContent = new Date().toLocaleDateString("en-PH", { weekday: "short", month: "short", day: "numeric", year: "numeric" });
renderAll();
