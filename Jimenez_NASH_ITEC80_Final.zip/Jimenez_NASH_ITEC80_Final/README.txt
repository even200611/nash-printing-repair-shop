NASH PRINTING & REPAIR SHOP MANAGEMENT SYSTEM
ITEC 80 - High-Fidelity Prototype Submission Package
Prepared by: Steven P. Jimenez

PACKAGE CONTENTS
- index.html: prototype page structure
- style.css: interface styling
- script.js: interactions and demo record handling
- README.txt: run instructions, demo workflow, testing notes, and limitations
- Screenshots/: nine screenshots supplied by the student, organized and renamed

HOW TO RUN THE INCLUDED CODE
1. Extract this ZIP file.
2. Open the extracted folder in Visual Studio Code.
3. Open index.html using Live Server, or open index.html in a browser.
4. Explore the pages using the navigation menu.

SCREENSHOT EVIDENCE INCLUDED
01 Dashboard (top)
02 Dashboard (workflow section)
03 New Request (form top)
04 New Request (form bottom)
05 Customers
06 Quotations
07 Job Orders
08 Payments & Records (top)
09 Payments & Records (payment history section)

IMPORTANT VERSION NOTE
The screenshots in Screenshots/ are the screenshots you provided of your current local NASH Printing & Repair Shop website. The HTML/CSS/JavaScript files included in this package are a separate prototype version generated for this package and may not match every label or layout shown in those screenshots. Before submission, open the included index.html and check it against your instructor's requirement. If your instructor requires the exact source code for the screenshots, submit the original project folder you used to create those screenshots instead of mixing versions.

SUGGESTED DEMO WORKFLOW
1. Open New Request and enter fictional test details.
2. Save the request.
3. Open Quotations and approve the quotation after entering a demo price.
4. Open Job Orders and update the production status.
5. Record a fictional payment from the related job.
6. Open Payments & Records and export the CSV if needed.

USABILITY ISSUES AND IMPROVEMENTS
1. Paper records can be hard to find. The prototype groups customer, quotation, job, and payment records into separate sections.
2. Production status can be difficult to track manually. Job Orders displays a status and provides a status update control.
3. Payments can be hard to match to a job. Payment records include transaction and job-order identifiers.

LIMITATIONS
- This is a student demonstration prototype, not a production system.
- The included code uses local browser storage and is not connected to a real database, login service, or payment gateway.
- Use fictional demo data only. Do not enter real customer or financial information.
- The screenshots currently show empty tables; for a stronger live demonstration, create one fictional request and capture the quotation, job order, and payment screens with sample records.
- If a public website URL is required, deploy the correct project version separately and submit that URL.

Prepared for academic demonstration. All sample records and amounts should be fictional.
